#! /usr/bin/sh
cp config/application-external.properties config/application.properties 

