package com.ge.predix.solsvc.impl;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

import javax.annotation.PostConstruct;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.ResponseBuilder;
import javax.ws.rs.core.Response.Status;

import org.apache.commons.io.IOUtils;
import org.apache.http.Header;
import org.apache.http.client.entity.GzipDecompressingEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.message.BasicHeader;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ge.predix.entity.timeseries.datapoints.ingestionrequest.Body;
import com.ge.predix.entity.timeseries.datapoints.ingestionrequest.DatapointsIngestion;
import com.ge.predix.entity.timeseries.datapoints.queryrequest.DatapointsQuery;
import com.ge.predix.entity.timeseries.datapoints.queryrequest.latest.DatapointsLatestQuery;
import com.ge.predix.entity.timeseries.datapoints.queryresponse.DatapointsResponse;
import com.ge.predix.solsvc.api.WindDataAPI;
import com.ge.predix.solsvc.restclient.impl.RestClient;
import com.ge.predix.solsvc.spi.IServiceManagerService;
import com.ge.predix.solsvc.timeseries.bootstrap.config.TimeseriesRestConfig;
import com.ge.predix.solsvc.timeseries.bootstrap.config.TimeseriesWSConfig;
import com.ge.predix.solsvc.timeseries.bootstrap.factories.TimeseriesFactory;


import java.io.*;
import java.net.*;
import java.util.*;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.ServerSocket;
import java.net.Socket;


//for Handshaking
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.xml.bind.DatatypeConverter;
import java.security.MessageDigest;

//for GET
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.UriInfo;


//Array concate
//import com.google.common.collect.ObjectArrays;
import java.util.Arrays;
import org.apache.commons.lang.ArrayUtils;
/**
 * 
 * @author predix -
 */
@Component
public class WindDataImpl  implements WindDataAPI {

	@Autowired
	private IServiceManagerService serviceManagerService;

	@Autowired
	private TimeseriesRestConfig timeseriesRestConfig;

	@Autowired
	private RestClient restClient;

	@Autowired
	private TimeseriesWSConfig tsInjectionWSConfig;


	@Autowired
	private TimeseriesFactory timeseriesFactory;


	private static Logger log = LoggerFactory.getLogger(WindDataImpl.class);

	/**
	 * -
	 */
	public WindDataImpl() {
		super();
	}
	
	 
public void startServerSocket() throws IOException 
{
ServerSocket serverSocket = null; 

    try { 
         serverSocket = new ServerSocket(10007); 
        } 
    catch (IOException e) 
        { 
         System.err.println("Could not listen on port: 10007."); 
         System.exit(1); 
        } 

    Socket clientSocket = null; 
    System.out.println ("Waiting for connection.....");

    try { 
         clientSocket = serverSocket.accept(); 
        } 
    catch (IOException e) 
        { 
         System.err.println("Accept failed."); 
         System.exit(1); 
        } 

    System.out.println ("Connection successful");
    System.out.println ("Waiting for input.....");
	
	PrintWriter out = new PrintWriter(clientSocket.getOutputStream(), 
                                      true); 
    BufferedReader in = new BufferedReader( 
            new InputStreamReader( clientSocket.getInputStream())); 

    String inputLine; 

			////ADD TO BASE//////////////////////////////////////////////
				System.out.println("\r\nAdd to database\r\n");
				
				this.serviceManagerService.createRestWebService(this, null);
				List<Header> headers = generateHeaders();
				headers.add(new BasicHeader("Origin", "http:predix.io"));	
				this.timeseriesFactory.createConnectionToTimeseriesWebsocket(headers);
				
				
				
    while ((inputLine = in.readLine()) != null) 
        { 
         System.out.println ("Server: " + inputLine); 
         out.println(inputLine); 
		
			
		////ADD TO BASE//////////////////////////////////////////////
				createMetrics(headers);
				
				
				
				

         if (inputLine.equals("Bye.")) 
             break; 
        } 
	
	/////////////////////////////////////////////////////
	this.timeseriesFactory.closeConnectionToTimeseriesWebsocket();
	System.out.print("\r\n-------------------------\rAdd to database Ok---------------------------------------\r\n");
	//////////////////////////////////////////////////////

    out.close(); 
    in.close(); 
    clientSocket.close(); 
    serverSocket.close(); 
    
}

	/**
	 * -
	 */
	@PostConstruct
	public void init() throws IOException  {
	  startServerSocket();
//		try{
//			startServerSocket();
//		}catch(IOException e){
//			e.printStackTrace();
//			System.out.println("-----Error SOCKET---------0000000000000000000000000000000000000000-----------000000000000000000000000000000------0000000000000000000");
//		}

		this.serviceManagerService.createRestWebService(this, null);
		List<Header> headers = generateHeaders();
		headers.add(new BasicHeader("Origin", "http://predix.io"));
		
		System.out.print("headers=="+headers);
//		this.timeseriesFactory.createConnectionToTimeseriesWebsocket(headers);
//		createMetrics(headers);
//		this.timeseriesFactory.closeConnectionToTimeseriesWebsocket();
		System.out.print("``````22222222222222222222````````````000000000000000000000000000000000```````````````````000000000000000000```````````");
	}

	@Override
	public Response greetings() {
		return handleResult("Greetings from CXF Bean Rest Service " + new Date()); //$NON-NLS-1$
	}
	
	
	
	
	
	
	
	
	//GET DATA////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	String Mes="test";
	String[] arrLat,arrLon,arrSpeed,arrLength,arrEle,arrTime;
	String nameCar;
	
	@Override
	public Response helloworld(String data) {
	System.out.print("\r\n-------------------------\r\nDATA="+data+"\r\n---------------------------------------");
 	
//// 	GET SPLIT DATA
	if (data.length()>=4) 
	{
	 	if (data.substring(0, 4).equals("NAME"))
	 	{
	 		nameCar=data.substring(12,data.length());
	 		System.out.println("\r\nnameCar"+nameCar);
	 	}

	 	if (data.substring(0, 4).equals("lat="))
	 	{
	 		data=data.substring(5,data.length());
	 		arrLat = (String[])ArrayUtils.addAll(arrLat,data.split("lat=\""));
//	 		arrLat = data.split("lat=\""); 
	 	  	System.out.println("\r\n");
			for(int i = 0; i < arrLat.length; i++) {
//				System.out.println("i="+i+"--"+arrLat[i]);
			}
	 
	 	
	 	}
	 	
	 	
	 	
	 	//ADD to base
	 	if (data.substring(0, 4).equals("END:"))
	 	{
	 		 
				System.out.println("\r\nAdd to database\r\n");
				System.out.print("\r\n======arrLat======="+arrLat.length+"\r\n");
				this.serviceManagerService.createRestWebService(this, null);
				List<Header> headers = generateHeaders();
				headers.add(new BasicHeader("Origin", "http:predix.io"));

				System.out.print("headers=="+headers);
				this.timeseriesFactory.createConnectionToTimeseriesWebsocket(headers);
				createMetrics(headers);
				this.timeseriesFactory.closeConnectionToTimeseriesWebsocket();
	 			System.out.print("\r\n-------------------------\rAdd to database Ok---------------------------------------\r\n");
	 			arrLat=null;arrLon=null;arrSpeed=null;arrLength=null;arrEle=null;arrTime=null;
				nameCar="";
	
	 	}

 	}
 	
 	
 	 
 	if (!data.equals("get")) 		
 	{ 	Mes=data;
 	return Response.ok()
      .header("Access-Control-Allow-Origin", "*")
      .header("Content-type","application/json")
      .header("Access-Control-Allow-Methods", "POST, GET, PUT, UPDATE, OPTIONS")
      .header("Access-Control-Allow-Headers", "Content-Type, Accept, X-Requested-With").build();
      }
   
    else
    { 
//    	return handleResult("Mes= " + Mes+" arrLat.length="+arrLat.length+ " arrLon.length="+arrLon.length+ " arrSpeed.length="+ " arrLength.length="+arrLength.length+ " arrEle.length="+arrEle.length+ " arrTime.length="+arrTime.length+ " nameCar="+nameCar); //$NON-NLS-1$
    	return handleResult("Mes= " + Mes);
	
	}
	}
	
    @Override
    public String helloworldHtml() {
        return "<html lang=\"en\"><body><h1>Hello, World!!</h1></body></html>";
//return handleResult("Greetings from CXF Bean Rest Service " + new Date()); //$NON-NLS-1$
    }
    

	@Override
	public Response getYearlyWindDataPoints(String id, String authorization,String starttime,String taglimit,String tagorder) {
		if (id == null) {
			return null;
		}
		
		List<Header> headers = generateHeaders();

		DatapointsQuery dpQuery = buildDatapointsQueryRequest(id, starttime,getInteger(taglimit),tagorder);
		System.out.print("-----------id-----------"+id);
		DatapointsResponse response = this.timeseriesFactory
				.queryForDatapoints(this.timeseriesRestConfig.getBaseUrl(),
						dpQuery, headers);
		log.debug(response.toString());

		return handleResult(response);
	}

	/**
	 * 
	 * @param s -
	 * @return
	 */
	private int getInteger(String s) {
		int inValue = 25;
		try {
			inValue = Integer.parseInt(s);
			
		} catch (NumberFormatException ex) {
			// s is not an integer
		}
		return inValue;
	}

	@Override
	public Response getLatestWindDataPoints(String id, String authorization) {
		if (id == null) {
			return null;
		}
		List<Header> headers = generateHeaders();

		DatapointsLatestQuery dpQuery = buildLatestDatapointsQueryRequest(id);
		DatapointsResponse response = this.timeseriesFactory
				.queryForLatestDatapoint(
						this.timeseriesRestConfig.getBaseUrl(), dpQuery,
						headers);
		log.debug(response.toString());

		return handleResult(response);
	}

	@SuppressWarnings({ "unqualified-field-access", "nls" })
	private List<Header> generateHeaders()
    {	
    	System.out.print("Hello ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
        List<Header> headers = this.restClient.getSecureTokenForClientId();
        System.out.print("getSecureTokenForClientId= "+this.restClient.getSecureTokenForClientId());
		this.restClient.addZoneToHeaders(headers,
				this.timeseriesRestConfig.getZoneId());
				System.out.print("getZoneId= "+this.timeseriesRestConfig.getZoneId());
        return headers;
    }


	private DatapointsLatestQuery buildLatestDatapointsQueryRequest(String id) {
		DatapointsLatestQuery datapointsLatestQuery = new DatapointsLatestQuery();

		com.ge.predix.entity.timeseries.datapoints.queryrequest.latest.Tag tag = new com.ge.predix.entity.timeseries.datapoints.queryrequest.latest.Tag();
		tag.setName(id);
		List<com.ge.predix.entity.timeseries.datapoints.queryrequest.latest.Tag> tags = new ArrayList<com.ge.predix.entity.timeseries.datapoints.queryrequest.latest.Tag>();
		tags.add(tag);
		datapointsLatestQuery.setTags(tags);
		return datapointsLatestQuery;
	}

	/**
	 * 
	 * @param id
	 * @param startDuration
	 * @param tagorder 
	 * @return
	 */
	private DatapointsQuery buildDatapointsQueryRequest(String id,
			String startDuration, int taglimit, String tagorder) {
		DatapointsQuery datapointsQuery = new DatapointsQuery();
		List<com.ge.predix.entity.timeseries.datapoints.queryrequest.Tag> tags = new ArrayList<com.ge.predix.entity.timeseries.datapoints.queryrequest.Tag>();
		datapointsQuery.setStart(startDuration);
		//datapointsQuery.setStart("1y-ago"); //$NON-NLS-1$
		String[] tagArray = id.split(","); //$NON-NLS-1$
		List<String> entryTags = Arrays.asList(tagArray);

		for (String entryTag : entryTags) {
			com.ge.predix.entity.timeseries.datapoints.queryrequest.Tag tag = new com.ge.predix.entity.timeseries.datapoints.queryrequest.Tag();
			tag.setName(entryTag);
			tag.setLimit(taglimit);
			tag.setOrder(tagorder); 
			tags.add(tag);
		}
		datapointsQuery.setTags(tags);
		return datapointsQuery;
	}



	@SuppressWarnings({ "nls", "unchecked" })
	private void createMetrics(List<Header> headers) {
	DatapointsIngestion dpIngestion;
	Body body;
	List<Object> datapoints;
	com.ge.predix.entity.util.map.Map map;
	List<Body> bodies;
			////////////////////////////////////////////////////////////////////////////////////
			// LAT
			////////////////////////////////////////////////////////////////////////////////////
			dpIngestion = new DatapointsIngestion();
			dpIngestion
					.setMessageId(String.valueOf(System.currentTimeMillis()));

			body = new Body();
			body.setName("Lat2016"); //$NON-NLS-1$
			

			datapoints = new ArrayList<Object>();
//			for(int i=0;i<arrLat.length;i++)
			{
 
			List<Object> datapointSend = new ArrayList<Object>();
			datapointSend.add(String.valueOf(System.currentTimeMillis()));
			datapointSend.add("123");
 			datapointSend.add(3); // quality
			
			
			datapoints.add(datapointSend);
			}
			


			body.setDatapoints(datapoints);

			map = new com.ge.predix.entity.util.map.Map();
			map.put("car", "service"); //$NON-NLS-2$
			map.put("track", "transport"); //$NON-NLS-2$

			body.setAttributes(map);

			bodies = new ArrayList<Body>();
			bodies.add(body);

			dpIngestion.setBody(bodies);
			this.timeseriesFactory.postDataToTimeseriesWebsocket(dpIngestion, headers);
			
			
			
			
			
						
			
		
	}


	@SuppressWarnings("javadoc")
	protected Response handleResult(Object entity) {
		ResponseBuilder responseBuilder = Response.status(Status.OK);
		responseBuilder.type(MediaType.APPLICATION_JSON);
		responseBuilder.entity(entity);
		return responseBuilder.build();
	}

	private Long generateTimestampsWithinYear(Long current) {
		long yearInMMS = Long.valueOf(31536000000L);
		return ThreadLocalRandom.current().nextLong(current - yearInMMS,
				current + 1);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ge.predix.solsvc.api.WindDataAPI#getWindDataTags()
	 */
	@Override
	public Response getWindDataTags() {
		List<Header> headers = generateHeaders();
		CloseableHttpResponse httpResponse = null;
		String entity = null;
		try {
			httpResponse = this.restClient
					.get(this.timeseriesRestConfig.getBaseUrl() + "/v1/tags", headers, this.timeseriesRestConfig.getTimeseriesConnectionTimeout(), this.timeseriesRestConfig.getTimeseriesSocketTimeout()); //$NON-NLS-1$

			if (httpResponse.getEntity() != null) {
				try {
					entity = processHttpResponseEntity(httpResponse.getEntity());
					log.debug("HttpEntity returned from Tags" + httpResponse.getEntity().toString()); //$NON-NLS-1$
				} catch (IOException e) {
					throw new RuntimeException(
							"Error occured calling=" + this.timeseriesRestConfig.getBaseUrl() + "/v1/tags", e); //$NON-NLS-1$//$NON-NLS-2$
				}
			}
		} finally {
			if (httpResponse != null)
				try {
					httpResponse.close();
				} catch (IOException e) {
					throw new RuntimeException(e);
				}
		}

		return handleResult(entity);
	}

	/**
	 * 
	 * @param entity
	 * @return
	 * @throws IOException
	 */
	@SuppressWarnings("nls")
	private String processHttpResponseEntity(org.apache.http.HttpEntity entity)
			throws IOException {
		if (entity == null)
			return null;
		if (entity instanceof GzipDecompressingEntity) {
			return IOUtils.toString(
					((GzipDecompressingEntity) entity).getContent(), "UTF-8");
		}
		return EntityUtils.toString(entity);
	}

}
