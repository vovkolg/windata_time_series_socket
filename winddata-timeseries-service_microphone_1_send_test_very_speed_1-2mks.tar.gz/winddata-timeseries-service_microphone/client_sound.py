#!/usr/bin/python
## This is an example of a simple sound capture script.
#http://stackoverflow.com/questions/4160175/detect-tap-with-pyaudio-from-live-mic/4160733#4160733
## https://chrisbaume.wordpress.com/2013/02/09/aubio-alsaaudio/
#https://andreymal.org/socket3/
#sudo apt-get install python python-alsaaudio python-aubio

import alsaaudio, time, audioop

import socket               # Import socket module
import datetime
s = socket.socket()         # Create a socket object
host = socket.gethostname() # Get local machine name
port = 10007                # Reserve a port for your service.

s.connect((host, port))

card='plughw:1'
inp = alsaaudio.PCM(alsaaudio.PCM_CAPTURE,alsaaudio.PCM_NONBLOCK, card)

# Set attributes: Mono, 8000 Hz, 16 bit little endian samples
inp.setchannels(1)
inp.setrate(28000)
inp.setformat(alsaaudio.PCM_FORMAT_S16_LE)


inp.setperiodsize(160)
#print int(time.time()*1000)
#print time.mktime(datetime.datetime.now().timetuple()) 
while True:
    # Read data from device
    l,data = inp.read()
    if l:
        # Return the maximum of the absolute value of all samples in a fragment.
         a = audioop.max(data, 2)
         if a>15000:
         	print "==="
         	print a
         	s.send(b""+str(int(time.time()*1000))+"|"+str(a)+"\n")
         	print s.recv(1024)
#         	s.send(b"Hello!\n")
#         	print s.recv(1024)
         	time.sleep(.001)
